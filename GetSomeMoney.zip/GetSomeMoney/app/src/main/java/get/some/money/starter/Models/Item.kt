package get.some.money.starter.Models

data class Item(
    val name: String,
    val imageURL: String,
    val price: Int
)